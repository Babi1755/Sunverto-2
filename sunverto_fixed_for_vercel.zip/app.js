
document.getElementById('app').innerHTML = '<p>این نسخه‌ی تستی Sunverto است. صفحه با موفقیت بارگذاری شد.</p>';
